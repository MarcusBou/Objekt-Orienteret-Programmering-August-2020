﻿using System;

namespace Queue
{
    class Program
    {
        static void Main(string[] args)
        {
            GUI gui = new GUI(true);
            gui.MainGUI();//refers too the main gui
        }
    }
}
